Miracl_Project-------------------------------直接调用大数库c文件的C-free 5工程
Miracl_Project_compile_lib------------------编译大数库为.a的C-free 5工程
Miracl_use_lib_example---------------------使用miracl.a静态库的C-free 5工程
miracl_5.5.4----------------------------------大数库Miracl的源码
MIRACL-master-----------------------------大数库Miracl的源码
miracl编译结果-------------------------------大数库Miracl的在VC和VS编译的静态库文件